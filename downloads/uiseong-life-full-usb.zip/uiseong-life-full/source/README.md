# 전체 서비스 원본 코드

이 폴더는 주거·농산물·지원·취업 전체 서비스의 재빌드 가능한 원본입니다.

일반 이용자는 상위 폴더의 index.html을 더블클릭하면 됩니다.
개발자가 수정할 때만 Node.js 18 이상을 사용해 이 폴더에서 실행하세요.

```sh
npm run build
npm test
```

외부 npm 패키지 설치는 필요 없습니다.
`npm run build`는 이 source 폴더 안의 index.html을 재생성합니다.
USB 메인 실행 파일에도 반영하려면 재생성된 index.html을 상위 폴더로 복사하세요.

- src/page.html: 화면 구조
- src/style.css: 디자인
- src/app.js: 사용자 입력과 화면 동작
- src/data.js: 가상데이터·검색·문장 조건 추출
- scripts/build.mjs: 외부 의존성 없는 단일 HTML 생성
- tests/search.test.js: 검색·금액·문장 조건 테스트

모든 자료는 예시이며, 문장 입력은 규칙 기반입니다.
